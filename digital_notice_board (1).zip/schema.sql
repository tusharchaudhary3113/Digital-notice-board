
CREATE TABLE IF NOT EXISTS notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    expiry_date TEXT NOT NULL,
    filename TEXT,
    created_at TEXT NOT NULL
);
